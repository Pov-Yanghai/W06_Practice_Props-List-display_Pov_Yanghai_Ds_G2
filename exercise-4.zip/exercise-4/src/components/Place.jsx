export default function Place() {
  return (
    <li key="the place id" className="place-item">
      <button>
        <img src={image} alt={alt} />
        <h3>{title}</h3>
      </button>
    </li>
  );
}
