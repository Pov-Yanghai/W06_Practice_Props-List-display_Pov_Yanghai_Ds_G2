/* Your data here */
import png1 from "./assets/1.png";
import png2 from "./assets/2.png";
import png3 from "./assets/3.png";
import png4 from "./assets/4.png";


const data = [
    {
      id: 1,
      name: "Dang",
      class: "Class A",
      hobbies: "Painting, Coding",
      imageUrl: png1, 
    },
    {
      id: 2,
      name: "Ding",
      class: "Class B",
      hobbies: "Cooking, Piano",
      imageUrl: png2, 
    },
    {
      id: 3,
      name: "Dung",
      class: "Class C",
      hobbies: "Video Games",
      imageUrl: png3, 
    },
    {
      id: 4,
      name: "Pov Yanghai",
      class: "E",
      hobbies: "Eating and Reading",
      imageUrl: png4, 
    }

  ];
  
  export default data;