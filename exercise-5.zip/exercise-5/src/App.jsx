import React from 'react';
import data from './data';
import './index.css';

function Card({person}) {
  return (
    <div className="card">
      <img src={person.imageUrl} alt={person.name} />
      <div className="card-details">
        <h3>{person.name}</h3>
        <p>Class: {person.class}</p>
        <p>Hobbies: {person.hobbies}</p>
      </div>
    </div>
  );
}
function App() {
  return <>{
    <div className = "app-container">
      {data.map((person) =>(
        <Card key={person.id} person={person} />
      ))}
    </div>
  }</>;
}

export default App;
